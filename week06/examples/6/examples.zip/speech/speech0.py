# Says hello

import pyttsx3

engine = pyttsx3.init()
engine.say("hello, world")
engine.runAndWait()